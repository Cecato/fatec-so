var app = require('./app/config/server'); // carregando o módulo do servidor

app.get('/', function(req,res){
   res.render("home/index");
});

app.get('/formulario_adicionar_usuario', function(req,res){
    res.render("admin/adicionar_usuario");
});

app.get('/info/historia', function(req,res){
   res.render("info/historia");
});

app.get('/info/cursos', function(req,res){
    res.render("info/cursos")
});

app.get('/info/professores', function(req,res){
    res.render("info/professores");
});

app.listen(3000, function(){
               console.log(texto);
});
